# Handoff: Thai Learn — Blue Rebrand + Practice Redesign

## Overview

Thai Learn (SwiftUI app + WidgetKit extension, `ThaiWallpaperLearn.xcodeproj`) is being rebranded from
the "Sukhothai Gold" warm parchment/indigo/gold palette to a **blue system**: pale-blue grounds,
a mid-blue primary accent, a light-blue second accent, navy ink. The Practice tab is also being
redesigned into one of three explored directions (flip deck / quest mode / choice grid).

Two things to implement:

1. **App-wide recolor** — replace the `ThaiTheme` palette (used by every screen and both widget
   families) with the blue tokens in *Design Tokens* below. Mechanical, do this first.
2. **Practice screen redesign** — rebuild `App/FlashcardView.swift` to one of the three designs
   in the prototype (default recommendation: **1a Flip Deck**, with the **1c Choice Grid** as an
   additional "Quick check" mode if the user wants it).

## About the design files

`Practice Redesign.dc.html` (plus `ios-frame.jsx`, `support.js`, `styles.css`) in this bundle are
**design references written in HTML/JS** — an interactive prototype showing the intended look,
motion and interaction. They are **not** production code to port.

The target codebase is **SwiftUI (iOS 17+, iOS 26 glass fallback already present)**. Recreate the
designs with the app's existing patterns: `ThaiTheme` tokens, the `ThaiUI.swift` component set
(`PrimaryButton`, `FilterChip`, `LanguageTag`, `WordCard`, `thaiGlass()`, `ProgressRing`), SwiftUI
animation. Do **not** introduce web views, new dependencies, or a new architecture.

Open the prototype: `Practice Redesign.dc.html` in a browser (or `Practice Redesign.standalone.html`,
a single self-contained file). Cards are clickable — flip, grade, reveal, pick an answer.

## Fidelity

**High fidelity.** Colors, type sizes, radii, spacing and animation timings below are final and
should be matched. Layout should be recreated closely, but use native iOS conventions where they
conflict (safe areas, `TabView`, system haptics, Dynamic Type).

## Design tokens

### Colors — new blue ramp

Replace the whole palette in `Shared/ThaiWord.swift` → `enum ThaiTheme`.

| Role | New hex | Replaces (old name) | Where used |
| --- | --- | --- | --- |
| `bg` page ground | `#EEF3FA` | `sand` #F6F0E4 | screen backgrounds |
| `bgAlt` alt ground | `#F5F8FC` | — | quiz screen ground |
| `surface` card | `#FBFDFF` | `cream` #FFFCF5 | cards, list rows |
| `surfaceSunken` | `#E3EBF5` | `parchment` #EFE6CF | pressed rows, chips |
| `hairline` | `#DCE5F0` | — | dividers, empty progress dots |
| `ink` text | `#101C33` | `ink` #2A2440 | primary text, Thai script |
| `inkDeep` | `#16233D` | `deepIndigo` | dark card face, gradients |
| `textMuted` | `#64748E` | `stone` #8A8577 | secondary text |
| `textFaint` | `#8C9CB4` | `stone` @60% | hints, counters |
| `accent100` | `#EAF2FC` | gold @16% | tinted pills |
| `accent200` | `#D8E7F8` | `lightGold` | category chip fill |
| `accent300` | `#AECDF0` | — | outlines on tinted fills |
| `accent400` | `#6F9FE0` | — | accents on dark grounds |
| **`accent` (primary)** | **`#2F6BC0`** | `indigo` #3D4C9E | primary buttons, active tab, rings |
| `accent600` hover | `#24559C` | — | hover |
| `accent700` pressed / text | `#1B4079` | — | accent-colored text, pressed |
| `accent2 100` | `#E6F3FB` | jade @12% | tone chips, correct-answer tint |
| `accent2 200` | `#CFE7F6` | — | correct answer fill |
| `accent2 300` | `#A9D3EA` | — | correct answer border |
| `accent2 400` | `#79B6DA` | — | light-blue accents on navy |
| **`accent2` (second)** | **`#3B7AA2`** | `jade` #1E6B55 | "Got it", success, streak sage |
| `accent2 600` | `#2C5F80` | — | pressed |
| `accent2 800` | `#1C3352` | — | text on light-blue fills |
| `danger` | `#C2503F` | keep-ish (`danger`) | "Again" only if needed as red; the designs use `accent100/300` instead |

Semantic mapping to keep the rest of the app working without edits:
`indigo → accent`, `gold → accent2 400 (#79B6DA)`, `orchid → accent700 (#1B4079)` (Devanagari
voice), `jade / success → accent2`, `plum → #4E92BD`, `stone → textMuted`, `classLow → accent2`.

Consonant-class colors (Alphabet tab) must stay **three distinguishable hues** — use
`middle #2F6BC0`, `high #1B4079`, `low #3B7AA2` and keep the class label text next to the dot.

Widget gradients (dark by design, keep dark): `thaiGradient` → `#101C33 → #1C3352`,
`englishGradient` → `#16233D → #2C5F80`, both top-leading → bottom-trailing.

Paste-ready Swift is in `ThaiTheme.blue.swift` in this bundle.

### Typography

| Role | Prototype font | iOS implementation |
| --- | --- | --- |
| Thai script (hero) | Mitr 500 | ship **Mitr-Medium.ttf** (Google, OFL) next to the existing Caladea fonts, register in `Info.plist`; fall back to `.system(design: .rounded)` |
| Hindi Devanagari | Noto Sans Devanagari 600 | ship **NotoSansDevanagari-SemiBold.ttf**, or system Devanagari at semibold |
| Display / titles | Caprasimo 400 | keep **Caladea-Bold** (already bundled) — Caprasimo is the web design system's voice; Caladea is the closest shipped face. Do not use Caprasimo on device unless you bundle it. |
| UI / body | Figtree 400–700 | `.system` (SF) — no new font needed |

Sizes (pt = px in the prototype):
- Thai hero on card: **66** (flip deck front), 58 (quest), 56 (quiz) — `minimumScaleFactor(0.4)`, 1 line
- Thai on card back / small: 34
- Screen title: 20–21 display
- Meaning, Hindi: **26** semibold (dark back) / 22 (inline reveal) / 20 (quiz tile)
- Meaning, English: **24** semibold / 20 / 15
- Pronunciation rows: 15
- Section kicker: 10–11 semibold, letterspacing +0.10em, uppercase
- Body/secondary: 11.5–13
- Tab labels: 10 semibold
**Hindi and English are the same size in every pair** — that is the point of the redesign. Never
render a meaning at caption size.

### Spacing, radius, elevation

- Screen side padding **22**; card inner padding 22–26; gaps 12 (button rows), 9–12 (stacked blocks)
- Radii: card **28**, inner block **20–24**, control/pill **999**, chip 999, tile 24
- Elevation: card `0 12px 32px rgba(16,28,51,0.18)`; raised card on navy `0 18px 40px rgba(0,0,0,0.40)`;
  small chrome `0 1px 2px rgba(16,28,51,0.14)`; primary button glow `0 3px 10px rgba(47,107,192,0.40)`
- Hit targets ≥ 44; the three action buttons are 56–74 tall/round

## Screens

### 1a Flip Deck — Practice (recommended)

**Purpose:** grade yourself on a due word; see both translations only after recall.

Layout, top → bottom, on `bg #EEF3FA` with two soft decorative circles (top-right 280pt radial
`accent200 → bg`, breathing 9s; bottom-left 240pt `accent2 100 → transparent`):

1. **Header** (padding top 62 for status bar): 40pt round back button (`surfaceSunken`, chevron
   `textMuted`, stroke 2.75) · title "Practice" (display 20) + subtitle "Session 3 · Everyday words"
   (11.5, `textMuted`) · streak pill (`accent100`, 🔥 + count, `accent700` bold 13, flame animates
   `flameFlick` 2.2s).
2. **Deck progress**: kicker "TODAY'S DECK" + "4/12" right-aligned; a **12-column grid** of 7pt
   pills, gap 5 — done = `accent`, current = `accent400`, remaining = `hairline`; background
   transitions 0.3s.
3. **Flip card** (fills remaining space, `perspective: 1400`, tap anywhere to flip,
   `rotateY(180deg)`, 0.62s `cubic-bezier(.2,.8,.2,1)`):
   - **Front** `surface`, radius 28: category chip (`accent200` fill, `accent700` 11 uppercase) ·
     Thai 66 centered · two tone chips ("High tone", "Short") in `accent2 100` with `accent2 300`
     border, `accent2 800` text · action row: "Hear it" pill (`accent` fill, speaker icon,
     display 16, `bg` text) + 52pt round "+" button (`surfaceSunken`) · hint "Tap card to reveal
     meaning" (11.5 `textFaint`).
   - **Back** `inkDeep #16233D`, radius 28: Thai 34 in `bg`; then two equal blocks
     (`rgba(238,243,250,.08)` fill, `rgba(238,243,250,.16)` border, radius 20) — "हिन्दी" label
     `accent400` + meaning 26 + pronunciation 15 `#B3C1D4`; "ENGLISH" label `accent2 400` +
     meaning 24 + romanization 15. Bottom: "IN A SENTENCE" + Thai example 17 + English gloss 13,
     above a 1px `rgba(238,243,250,.14)` rule.
4. **Grade row**: "Again" (flex, 56 tall, `accent100` fill, 1.5pt `accent300` border, refresh icon,
   `accent700` display 16) and "Got it" (flex, `accent2` fill, check icon, `bg` text, glow).
   Again → next word, progress unchanged. Got it → next word, progress +1. Both reset the flip.
5. **Tab bar**: 5 items (Today / Practice / Browse / Alphabet / More), active `accent700` +
   full-opacity icon, inactive `textFaint` + 0.4 opacity, on `rgba(251,253,255,.7)` with a
   `rgba(16,28,51,.08)` top rule, bottom padding 34.

### 1b Quest Mode — Practice (alternative, gamified)

Navy gradient ground `#101C33 → #16233D → #1C3352` with a breathing blue radial glow.
Header: Level pill (28pt `accent` numeral badge), 🪙 coins pill (`accent400` tinted), 🔥 streak pill
(`accent2 400` tinted). **XP bar**: 12pt track `rgba(238,243,250,.12)`, fill
`linear-gradient(90deg,#2F6BC0,#6F9FE0)`, width transitions 0.5s; label "XP to level 8 — 260 / 400".
Card stack: two offset ghost cards behind the live card (`surface`, radius 28, shadow
`0 18px 40px rgba(0,0,0,.4)`) holding emoji 38 · Thai 58 · tone chips · a **"Show meaning"** button
(`ink` fill) that swaps to two inline blocks (HI on `accent100`, EN on `accent2 100`, radius 20,
`slideUp` 0.34s). Bottom: 62pt "Again" ring (outlined `accent300`), 74pt `accent` speaker button
with glow, 62pt `accent2 400` check button. Grading slides the card off
(`translateX(±120%) rotate(±14deg)`, opacity 0, 0.42s), advances after 420ms; "Got it" also floats
a **"+10 XP"** label upward (`floatUp` 1s) and adds 10 XP.

### 1c Choice Grid — "Quick check" mode

Ground `bgAlt #F5F8FC`, one top-left radial. Header: 52pt SVG **progress ring** (22 r, 6 stroke,
track `surfaceSunken`, progress `accent`, dashoffset transitions 0.5s) with position number inside;
title "Quick check" + "6 right · 1 to review"; 🌱 pill (`accent2 100`).
Prompt card (`surface`, radius 28, shadow-sm): kicker "WHAT DOES THIS MEAN?" · Thai 56 · romanization
and Devanagari pronunciation separated by a 5pt dot · "Hear it" pill (`accent200`).
**Answer grid**: 2×2, gap 12, tiles radius 24, 1.5pt border — each tile shows **Hindi 20 semibold
above English 15 semibold**. Idle `surface`/`surfaceSunken` border. On pick: correct tile
`accent2 200` fill / `accent2 300` border / `popIn` 0.34s; wrong tile `accent200` fill /
`#3F7BD0` border / `shake` 0.34s; the un-picked tiles fade to `textFaint`. Locked after one pick.
Bottom CTA changes label and color: idle "Skip this word" (`surfaceSunken`, `#44546E`),
correct "Nice — next word" (`accent2`), wrong "Got it, next word" (`accent`).

### Other screens (recolor only, no layout change)

- **Today** — `WordCard` on `bg`; category chip `accent200`/`accent700`; HI row `accent700`,
  EN row `accent`; streak pill `accent100`; "Play" = `PrimaryButton` on `accent`; shuffle button
  `surfaceSunken`. Raise the two meaning rows to 21pt so HI and EN match.
- **Browse** — rows on `surface`, `bg` behind the list; progress dot: unseen `hairline`,
  learning `accent400`, known `accent2`; filter chips selected `accent`/white, else
  `surfaceSunken`/`ink`.
- **Alphabet** — class colors as above; sound badge `accent2 400` fill with `ink` text (not white —
  contrast); Devanagari cousin in `accent700`.
- **More** — row icon tiles: slang `accent700`, cousins `accent`, opposites `accent2`,
  similar `#4E92BD`, facts `accent400`; radius 10 → **14** to match the rounder system.
- **Widgets** — keep dark; use the two navy gradients above, Thai in `#EEF3FA`, romanization
  `#AECDF0`, Hindi `#79B6DA`.

## Interactions & behavior

| Interaction | Trigger | Behavior |
| --- | --- | --- |
| Flip card | tap card | 3D Y flip 0.62s `cubic-bezier(.2,.8,.2,1)`; SwiftUI: `rotation3DEffect` + `.animation(.spring(response:0.45, dampingFraction:0.8))` |
| Again | tap | advance deck, keep progress, unflip |
| Got it | tap | advance deck, progress +1, Leitner box +1 (existing `ProgressStore`) |
| Reveal (1b) | tap "Show meaning" or speaker | inline blocks appear, `slideUp` 0.34s |
| Grade (1b) | tap ✓ / ↺ | card exits ±120% with ±14° rotation, opacity → 0, 0.42s; new card enters after 420ms; ✓ adds 10 XP and floats "+10 XP" up 54pt over 1s |
| Pick answer (1c) | tap tile | lock grid, animate correct/wrong, update right/review counts |
| Next (1c) | tap CTA | reset pick, next word |
| Hear it | tap | existing `SpeechService.speak(thai:romanization:)`; add a light haptic |
| Hover/press | — | on iOS use `.scaleEffect(0.97)` + the pressed ramp step (`accent600`/`accent2 600`) |

All motion is a spring or ease-out under 0.65s. No motion on Dynamic Type / Reduce Motion: honor
`@Environment(\.accessibilityReduceMotion)` — swap the flip for a cross-fade.

## State

Per Practice session (reuse `ProgressStore` and the existing ThaiFlow deck ordering):
`deck: [ThaiWord]`, `index: Int`, `isFlipped / isRevealed: Bool`, `doneCount: Int`,
`sessionTarget: Int = 12`, `streak: Int` (from `ProgressStore.currentStreak()`),
plus for 1b `xp: Int`, `level: Int`, `coins: Int`, `exitDirection: Int` and for 1c
`picked: Int?`, `rightCount: Int`, `reviewCount: Int`, and a per-word `choices: [ThaiWord]` +
`answerIndex: Int` built from 3 same-category distractors (fall back to random words).

## Assets

- No images. Decorative shapes are radial gradients / circles — reproduce with SwiftUI `Circle()`
  + `RadialGradient` and `.blur()`.
- Icons: prototype uses Lucide paths at stroke-width 2.75. In SwiftUI use SF Symbols with
  `.font(.system(size:, weight: .bold))`: `chevron.left`, `speaker.wave.2.fill`, `plus`,
  `arrow.counterclockwise`, `checkmark`, `eye.fill`, `arrow.right`.
- Emoji used as-is: 🔥 🪙 🌱 💧 😋 🙏 🌿 🛵 and the tab glyphs (☀️ 🃏 📖 ก ✨) — replace tab glyphs
  with SF Symbols in the app (`sun.max.fill`, `rectangle.on.rectangle.angled`, `list.bullet`,
  `character.book.closed.fill`, `sparkles`).
- Fonts to add: Mitr-Medium, NotoSansDevanagari-SemiBold (both OFL, from Google Fonts).

## Files in this bundle

| File | What it is |
| --- | --- |
| `Practice Redesign.dc.html` | the interactive prototype (three options side by side) |
| `Practice Redesign.standalone.html` | same prototype, single self-contained file |
| `ios-frame.jsx`, `support.js` | prototype runtime — reference only, do not port |
| `styles.css` | the web design-system token sheet the prototype styles against |
| `ThaiTheme.blue.swift` | paste-ready replacement palette for `Shared/ThaiWord.swift` |

## Suggested order of work

1. Swap the palette (`ThaiTheme.blue.swift`), build, sweep every screen + both widgets for
   leftover warm hexes (`ContentView.swift` has one inline `Color(red: 0.541, green: 0.373…)`).
2. Bundle the two fonts, add a `ThaiTheme.thai(_:)` and `ThaiTheme.devanagari(_:)` helper, and
   raise all meaning text so HI and EN match.
3. Rebuild Practice as 1a; keep the existing deck ordering and grading logic untouched.
4. Optional: add 1c as a second Practice mode behind a segmented control ("Cards" / "Quick check").
