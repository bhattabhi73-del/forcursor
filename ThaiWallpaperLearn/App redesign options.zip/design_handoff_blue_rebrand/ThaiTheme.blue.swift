import SwiftUI

// Blue rebrand palette — drop-in replacement for the color block of
// `enum ThaiTheme` in Shared/ThaiWord.swift. Old names are kept as aliases so
// existing views compile unchanged; prefer the new semantic names in new code.
//
// Ground: pale blue. Primary accent: mid blue. Second accent: light blue.
// Ink: navy. Spacing/radius scale unchanged except radiusChip → 14.
extension ThaiTheme {

    // MARK: New semantic roles

    static let bg            = Color(hex: 0xEEF3FA)  // page ground
    static let bgAlt         = Color(hex: 0xF5F8FC)  // alternate ground (quiz)
    static let surface       = Color(hex: 0xFBFDFF)  // cards, rows
    static let surfaceSunken = Color(hex: 0xE3EBF5)  // chips, pressed rows
    static let hairline      = Color(hex: 0xDCE5F0)  // dividers, empty progress

    static let inkNavy       = Color(hex: 0x101C33)  // primary text, Thai script
    static let inkDeep       = Color(hex: 0x16233D)  // dark card face
    static let textMuted     = Color(hex: 0x64748E)
    static let textFaint     = Color(hex: 0x8C9CB4)

    static let accent100     = Color(hex: 0xEAF2FC)
    static let accent200     = Color(hex: 0xD8E7F8)
    static let accent300     = Color(hex: 0xAECDF0)
    static let accent400     = Color(hex: 0x6F9FE0)
    static let accent        = Color(hex: 0x2F6BC0)  // primary
    static let accent600     = Color(hex: 0x24559C)  // hover
    static let accent700     = Color(hex: 0x1B4079)  // pressed / accent text

    static let accent2100    = Color(hex: 0xE6F3FB)
    static let accent2200    = Color(hex: 0xCFE7F6)
    static let accent2300    = Color(hex: 0xA9D3EA)
    static let accent2400    = Color(hex: 0x79B6DA)
    static let accent2       = Color(hex: 0x3B7AA2)  // second voice / success
    static let accent2600    = Color(hex: 0x2C5F80)
    static let accent2800    = Color(hex: 0x1C3352)

    // MARK: Aliases for the old warm names (so existing views keep compiling)

    static let sandBlue      = bg
    static let creamBlue     = surface
    static let parchmentBlue = surfaceSunken

    // Replace the originals with these bodies in ThaiWord.swift:
    //   static let sand       = Color(hex: 0xEEF3FA)
    //   static let cream      = Color(hex: 0xFBFDFF)
    //   static let parchment  = Color(hex: 0xE3EBF5)
    //   static let ink        = Color(hex: 0x101C33)
    //   static let indigo     = Color(hex: 0x2F6BC0)
    //   static let deepIndigo = Color(hex: 0x16233D)
    //   static let gold       = Color(hex: 0x79B6DA)
    //   static let lightGold  = Color(hex: 0xD8E7F8)
    //   static let orchid     = Color(hex: 0x1B4079)   // Devanagari voice
    //   static let jade       = Color(hex: 0x3B7AA2)
    //   static let plum       = Color(hex: 0x4E92BD)
    //   static let stone      = Color(hex: 0x64748E)
    //   static let success    = Color(hex: 0x3B7AA2)
    //   static let danger     = Color(hex: 0xC2503F)
    //   static let classLow   = Color(hex: 0x3B7AA2)
    //   static let radiusChip: CGFloat = 14

    // MARK: Tone / consonant-class hues (must stay distinguishable)

    static let classMiddleBlue = Color(hex: 0x2F6BC0)
    static let classHighBlue   = Color(hex: 0x1B4079)
    static let classLowBlue    = Color(hex: 0x3B7AA2)

    // MARK: Washes & widget gradients (widgets stay dark by design)

    static let blueWash = LinearGradient(
        colors: [bg, surfaceSunken.opacity(0.85), bg],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    static let thaiGradientBlue = LinearGradient(
        colors: [Color(hex: 0x101C33), Color(hex: 0x1C3352)],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    static let englishGradientBlue = LinearGradient(
        colors: [Color(hex: 0x16233D), Color(hex: 0x2C5F80)],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    // MARK: Type helpers — bundle Mitr-Medium and NotoSansDevanagari-SemiBold
    // and register them under UIAppFonts in Info.plist.

    static func thai(_ size: CGFloat) -> Font {
        .custom("Mitr-Medium", size: size)   // falls back to system if missing
    }

    static func devanagari(_ size: CGFloat) -> Font {
        .custom("NotoSansDevanagari-SemiBold", size: size)
    }
}

extension Color {
    /// 0xRRGGBB convenience initializer.
    init(hex: UInt32) {
        self.init(
            red:   Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue:  Double(hex & 0xFF) / 255)
    }
}
